package dev.raistey.raisskysecrets;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.phys.Vec3;
import net.minecraftforge.client.event.AddGuiOverlayLayersEvent;
import net.minecraftforge.client.event.ClientChatReceivedEvent;
import net.minecraftforge.client.event.RegisterKeyMappingsEvent;
import net.minecraftforge.client.event.SystemMessageReceivedEvent;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.EntityLeaveLevelEvent;
import net.minecraftforge.event.entity.player.PlayerInteractEvent;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

final class ClientController {
    private static final Identifier HUD_LAYER = Identifier.fromNamespaceAndPath(RaisSkySecrets.MOD_ID, "secret_hud");
    private static final KeyMapping TOGGLE = key("key.raissky_secrets.toggle", InputConstants.KEY_P);
    private static final KeyMapping UTILITY = key("key.raissky_secrets.utility", InputConstants.KEY_O);
    private static final KeyMapping REFRESH = key("key.raissky_secrets.refresh", InputConstants.KEY_K);
    private static final KeyMapping ROUTE = key("key.raissky_secrets.route", InputConstants.KEY_R);
    private static final KeyMapping HUD_POS = key("key.raissky_secrets.hud_position", InputConstants.KEY_L);
    private static final KeyMapping MANUAL_DONE = key("key.raissky_secrets.manual_done", InputConstants.KEY_H);

    private static final RoomMatcher MATCHER = new RoomMatcher();
    private static final SecretStateTracker SECRET_STATE = new SecretStateTracker();
    private static final PartySecretSync PARTY_SYNC = new PartySecretSync();
    private static final RouteNavigator ROUTE_NAV = new RouteNavigator();
    private static final PuzzleAssistant PUZZLE = new PuzzleAssistant();
    private static final Pattern SECRET_COUNTER = Pattern.compile("(\\d{1,2})/(\\d{1,2}) Secrets");

    private static volatile Models.DatabaseState databaseState = Models.DatabaseState.LOADING;
    private static volatile String databaseMessage = "Preparing room database…";
    private static volatile RoomDatabase database;
    private static volatile Models.HudSnapshot snapshot = Models.HudSnapshot.empty(
            Models.DatabaseState.LOADING, databaseMessage, true, true);

    private static boolean enabled = true;
    private static boolean showUtility = true;
    private static boolean routeEnabled = true;
    private static Models.HudPosition hudPosition = Models.HudPosition.BOTTOM;
    private static int ticks;
    private static int lastRoomSeenTick = -100000;

    private ClientController() {}

    private static KeyMapping key(String name, int key) {
        return new KeyMapping(name, InputConstants.Type.KEYSYM, key, KeyMapping.Category.MISC);
    }

    static void register() {
        RegisterKeyMappingsEvent.BUS.addListener(ClientController::registerKeys);
        AddGuiOverlayLayersEvent.BUS.addListener(ClientController::registerHud);
        TickEvent.ClientTickEvent.Post.BUS.addListener(event -> tick());
        PlayerInteractEvent.RightClickBlock.BUS.addListener(ClientController::onRightClickBlock);
        EntityLeaveLevelEvent.BUS.addListener(ClientController::onEntityLeaveLevel);
        SystemMessageReceivedEvent.BUS.addListener(ClientController::onSystemMessage);
        ClientChatReceivedEvent.BUS.addListener(ClientController::onChatMessage);
        beginDatabaseLoad(false);
    }

    private static void registerKeys(RegisterKeyMappingsEvent event) {
        event.register(TOGGLE); event.register(UTILITY); event.register(REFRESH);
        event.register(ROUTE); event.register(HUD_POS); event.register(MANUAL_DONE);
    }

    private static void registerHud(AddGuiOverlayLayersEvent event) {
        // Added as a late HUD layer; L also lets the user move it away from conflicting HUD mods.
        event.getLayeredDraw().add(HUD_LAYER, (graphics, deltaTracker) -> SecretHud.extract(graphics));
    }

    static Models.HudSnapshot snapshot() { return snapshot; }
    static Models.HudPosition hudPosition() { return hudPosition; }
    static boolean routeEnabled() { return routeEnabled; }
    static int routePointCount() { return ROUTE_NAV.pointCount(); }
    static boolean hudContextActive() {
        return MATCHER.matched() != null || MATCHER.candidateCount() > 0 || ticks - lastRoomSeenTick <= 80;
    }
    static String puzzleHint() { return PUZZLE.hint(MATCHER.matched()); }
    static boolean applyPartySync(Models.SyncUpdate update) { return SECRET_STATE.applySynced(update); }

    static void onPartySyncChanged() {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player == null || mc.level == null) return;
        Models.RoomCandidate room = MATCHER.matched();
        if (room != null) refreshSnapshotImmediately(mc, room);
    }

    private static void beginDatabaseLoad(boolean forceRefresh) {
        databaseState = Models.DatabaseState.LOADING;
        databaseMessage = forceRefresh ? "Refreshing room database…" : "Preparing room database…";
        snapshot = Models.HudSnapshot.empty(databaseState, databaseMessage, enabled, showUtility);
        CompletableFuture<RoomDatabase> future = RoomDatabase.prepare(forceRefresh);
        future.whenComplete((loaded, error) -> Minecraft.getInstance().execute(() -> {
            if (error != null) {
                databaseState = Models.DatabaseState.ERROR;
                databaseMessage = rootMessage(error);
                RaisSkySecrets.LOGGER.error("Failed to prepare room database", error);
            } else {
                database = loaded;
                MATCHER.setDatabase(loaded);
                databaseState = Models.DatabaseState.READY;
                databaseMessage = loaded.roomCount() + " rooms loaded";
                notifyPlayer("RaisSky Secrets 0.2.1 · " + loaded.roomCount() + " rooms ready");
            }
        }));
    }

    private static void tick() {
        Minecraft mc = Minecraft.getInstance();
        ticks++;

        while (TOGGLE.consumeClick()) {
            enabled = !enabled;
            notifyPlayer("Secret Waypoints: " + (enabled ? "ON" : "OFF"));
        }
        while (UTILITY.consumeClick()) {
            showUtility = !showUtility;
            notifyPlayer("Route Helpers: " + (showUtility ? "ON" : "OFF"));
        }
        while (REFRESH.consumeClick()) {
            beginDatabaseLoad(true);
            notifyPlayer("Refreshing Secret room database…");
        }
        while (ROUTE.consumeClick()) {
            routeEnabled = !routeEnabled;
            if (!routeEnabled) ROUTE_NAV.reset();
            notifyPlayer("Ground Route: " + (routeEnabled ? "ON" : "OFF"));
        }
        while (HUD_POS.consumeClick()) {
            hudPosition = nextHudPosition(hudPosition);
            notifyPlayer("RaisSky HUD: " + hudPosition.name());
        }

        SECRET_STATE.updateLevel(mc);
        if (!enabled || mc.player == null || mc.level == null) {
            ROUTE_NAV.reset();
            snapshot = Models.HudSnapshot.empty(databaseState, databaseMessage, enabled, showUtility);
            return;
        }
        if (databaseState != Models.DatabaseState.READY || database == null) {
            snapshot = Models.HudSnapshot.empty(databaseState, databaseMessage, enabled, showUtility);
            return;
        }

        if (ticks % 10 == 0) MATCHER.update(mc);
        Models.RoomCandidate room = MATCHER.matched();
        if (room != null) lastRoomSeenTick = ticks;
        PUZZLE.tick(mc, room);

        List<Models.WorldWaypoint> allForTracking = MATCHER.worldWaypoints(true);
        boolean stateChanged = SECRET_STATE.tick(mc, room, allForTracking);
        if (room != null) PARTY_SYNC.tick(mc, SECRET_STATE);

        List<Models.WorldWaypoint> allForDisplay = showUtility ? allForTracking : MATCHER.worldWaypoints(false);
        List<Models.WorldWaypoint> visibleReal = SECRET_STATE.visible(room, allForDisplay);

        while (MANUAL_DONE.consumeClick()) {
            Models.WorldWaypoint marked = SECRET_STATE.manualResolveNearest(room, visibleReal, mc.player.position());
            if (marked == null) notifyPlayer("Manual Done: no marker within 12 blocks");
            else {
                notifyPlayer("Manual Done: " + marked.category() + " #" + marked.secretIndex());
                stateChanged = true;
                visibleReal = SECRET_STATE.visible(room, allForDisplay);
            }
        }

        List<Models.WorldWaypoint> display = withPuzzleTarget(visibleReal, PUZZLE.target());
        Models.WorldWaypoint next = nearest(display, mc.player.position());
        ROUTE_NAV.tick(mc, next, routeEnabled);

        snapshot = new Models.HudSnapshot(true, databaseState, databaseMessage,
                room == null ? "" : room.definition().roomName(),
                room == null ? null : room.direction(), MATCHER.candidateCount(),
                mc.player.position(), mc.player.getYRot(), display, showUtility);

        if (stateChanged && room != null) refreshSnapshotImmediately(mc, room);
        if (ticks % 4 == 0 && !display.isEmpty()) spawnColoredMarkers(mc, display, next);
    }

    private static void onRightClickBlock(PlayerInteractEvent.RightClickBlock event) {
        Minecraft mc = Minecraft.getInstance();
        if (!enabled || mc.player == null || mc.level == null || event.getEntity() != mc.player) return;
        Models.RoomCandidate room = MATCHER.matched();
        if (room == null) return;
        PUZZLE.onRightClick(event.getPos());
        String heldItemName = event.getItemStack().isEmpty() ? "" : event.getItemStack().getHoverName().getString();
        if (SECRET_STATE.onRightClick(room, MATCHER.worldWaypoints(true), event.getPos(), heldItemName)) {
            refreshSnapshotImmediately(mc, room);
        }
    }

    private static void onEntityLeaveLevel(EntityLeaveLevelEvent event) {
        Minecraft mc = Minecraft.getInstance();
        if (!enabled || mc.player == null || mc.level == null || event.getLevel() != mc.level) return;
        Models.RoomCandidate room = MATCHER.matched();
        if (room != null && SECRET_STATE.onEntityRemoved(room, MATCHER.worldWaypoints(true), event.getEntity())) {
            refreshSnapshotImmediately(mc, room);
        }
    }

    private static void onSystemMessage(SystemMessageReceivedEvent event) { processIncoming(event.getMessage()); }
    private static void onChatMessage(ClientChatReceivedEvent event) { processIncoming(event.getMessage()); }

    private static void processIncoming(Component message) {
        Minecraft mc = Minecraft.getInstance();
        if (!enabled || mc.player == null || mc.level == null || message == null) return;
        Models.RoomCandidate room = MATCHER.matched();
        if (room == null) return;
        PUZZLE.onMessage(mc, room, message);
        Matcher counter = SECRET_COUNTER.matcher(message.getString());
        if (counter.find()) {
            int found = Integer.parseInt(counter.group(1));
            int max = Integer.parseInt(counter.group(2));
            SECRET_STATE.onSecretCounter(mc, room, MATCHER.worldWaypoints(true), found, max);
        }
        refreshSnapshotImmediately(mc, room);
    }

    private static void refreshSnapshotImmediately(Minecraft mc, Models.RoomCandidate room) {
        List<Models.WorldWaypoint> visible = SECRET_STATE.visible(room, MATCHER.worldWaypoints(showUtility));
        List<Models.WorldWaypoint> display = withPuzzleTarget(visible, PUZZLE.target());
        snapshot = new Models.HudSnapshot(true, databaseState, databaseMessage,
                room.definition().roomName(), room.direction(), MATCHER.candidateCount(),
                mc.player.position(), mc.player.getYRot(), display, showUtility);
    }

    private static List<Models.WorldWaypoint> withPuzzleTarget(List<Models.WorldWaypoint> real, Models.WorldWaypoint puzzle) {
        if (puzzle == null) return real;
        List<Models.WorldWaypoint> out = new ArrayList<>(real.size() + 1);
        out.add(puzzle); out.addAll(real);
        return List.copyOf(out);
    }

    private static Models.WorldWaypoint nearest(List<Models.WorldWaypoint> waypoints, Vec3 player) {
        return waypoints.stream().min(Comparator.comparingDouble(w -> w.center().distanceToSqr(player))).orElse(null);
    }

    private static void spawnColoredMarkers(Minecraft mc, List<Models.WorldWaypoint> waypoints, Models.WorldWaypoint next) {
        Vec3 player = mc.player.position();
        List<Models.WorldWaypoint> nearest = waypoints.stream()
                .filter(w -> w.center().distanceToSqr(player) <= 58.0 * 58.0)
                .sorted(Comparator.comparingDouble(w -> w.center().distanceToSqr(player))).limit(18).toList();
        for (Models.WorldWaypoint waypoint : nearest) {
            boolean focused = waypoint == next;
            int rgb = SecretHud.categoryRgb(waypoint.category());
            DustParticleOptions dust = new DustParticleOptions(rgb, focused ? 1.25f : 0.85f);
            Vec3 c = waypoint.center();
            double radius = focused ? 0.58 : 0.40;
            int points = focused ? 12 : 8;
            for (int i = 0; i < points; i++) {
                double a = i * Math.PI * 2.0 / points;
                mc.particleEngine.createParticle(dust, c.x + Math.cos(a) * radius, c.y + Math.sin(a) * 0.35,
                        c.z + Math.sin(a) * radius, 0, 0.001, 0);
            }
            if (focused) mc.particleEngine.createParticle(ParticleTypes.END_ROD, c.x, c.y + 0.55, c.z, 0, 0.01, 0);
        }
    }

    private static Models.HudPosition nextHudPosition(Models.HudPosition current) {
        return switch (current) {
            case BOTTOM -> Models.HudPosition.TOP;
            case TOP -> Models.HudPosition.LEFT;
            case LEFT -> Models.HudPosition.RIGHT;
            case RIGHT -> Models.HudPosition.OFF;
            case OFF -> Models.HudPosition.BOTTOM;
        };
    }

    private static void notifyPlayer(String message) {
        Minecraft mc = Minecraft.getInstance();
        if (mc.player != null) mc.player.sendSystemMessage(Component.literal(message));
    }

    private static String rootMessage(Throwable throwable) {
        Throwable current = throwable;
        while (current.getCause() != null) current = current.getCause();
        String message = current.getMessage();
        return message == null || message.isBlank() ? current.getClass().getSimpleName() : message;
    }
}
