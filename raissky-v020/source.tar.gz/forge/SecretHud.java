package dev.raistey.raisskysecrets;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.world.phys.Vec3;

import java.util.Comparator;
import java.util.List;
import java.util.Locale;

/** Compact movable HUD. Bottom-center is the default to reduce conflicts with common dungeon HUD mods. */
final class SecretHud {
    private SecretHud() {}

    static void extract(GuiGraphicsExtractor graphics) {
        Models.HudSnapshot snapshot = ClientController.snapshot();
        Models.HudPosition position = ClientController.hudPosition();
        if (!snapshot.enabled() || position == Models.HudPosition.OFF) return;

        if (snapshot.databaseState() != Models.DatabaseState.READY) {
            drawStatus(graphics, position,
                    snapshot.databaseState() == Models.DatabaseState.ERROR ? 0xFFFF667A : 0xFF69E6FF,
                    snapshot.databaseState() == Models.DatabaseState.ERROR ? "SECRET DB ERROR" : "SECRET DB LOADING",
                    snapshot.databaseMessage());
            return;
        }

        String puzzleHint = ClientController.puzzleHint();
        if ((snapshot.waypoints().isEmpty() || snapshot.playerPos() == Vec3.ZERO) && puzzleHint.isBlank()) return;

        List<WaypointDistance> sorted = snapshot.waypoints().stream()
                .map(w -> new WaypointDistance(w, w.center().distanceTo(snapshot.playerPos())))
                .sorted(Comparator.comparingDouble(WaypointDistance::distance)).toList();
        WaypointDistance next = sorted.isEmpty() ? null : sorted.getFirst();
        drawMain(graphics, snapshot, next, puzzleHint, position);
    }

    private static void drawMain(GuiGraphicsExtractor g, Models.HudSnapshot snapshot,
                                 WaypointDistance next, String puzzleHint, Models.HudPosition position) {
        Minecraft mc = Minecraft.getInstance();
        int width = 238;
        int height = puzzleHint.isBlank() ? 54 : 68;
        int[] xy = origin(g, position, width, height);
        int x = xy[0], y = xy[1];
        int accent = next == null ? 0xFF40FF70 : categoryColor(next.waypoint.category());

        g.fill(x + 3, y + 3, x + width + 3, y + height + 3, 0x66000000);
        g.fill(x, y, x + width, y + height, 0xE510141C);
        g.fill(x, y, x + width, y + 2, accent);
        g.outline(x, y, width, height, 0x774A5568);

        String title = next == null ? "PUZZLE ASSIST" : "NEXT · " + prettyCategory(next.waypoint.category());
        g.text(mc.font, title, x + 8, y + 7, accent, true);

        if (next != null) {
            Vec3 target = next.waypoint.center();
            double dx = target.x - snapshot.playerPos().x;
            double dy = target.y - snapshot.playerPos().y;
            double dz = target.z - snapshot.playerPos().z;
            String arrow = directionArrow(dx, dz, snapshot.playerYaw());
            String vertical = Math.abs(dy) < 1.6 ? "LEVEL" : (dy > 0 ? "UP " + format1(Math.abs(dy)) + "m" : "DOWN " + format1(Math.abs(dy)) + "m");
            String line = arrow + "  " + format1(next.distance) + "m  ·  " + vertical;
            g.text(mc.font, line, x + 9, y + 24, 0xFFFFFFFF, true);
        }

        String room = snapshot.roomName().isBlank() ? "Matching room…" : snapshot.roomName();
        String footer = room + " · " + snapshot.waypoints().size() + " markers"
                + (ClientController.routeEnabled() ? " · ROUTE ON" : " · ROUTE OFF");
        g.text(mc.font, trim(mc, footer, width - 16), x + 8, y + 41, 0xFF9CA8BA, false);

        if (!puzzleHint.isBlank()) {
            g.fill(x + 6, y + 52, x + width - 6, y + 65, 0x66213D2B);
            g.text(mc.font, trim(mc, puzzleHint, width - 20), x + 10, y + 55, 0xFF72FF98, true);
        }
    }

    private static void drawStatus(GuiGraphicsExtractor g, Models.HudPosition pos, int accent, String title, String detail) {
        Minecraft mc = Minecraft.getInstance();
        int w = 238, h = 38;
        int[] xy = origin(g, pos, w, h);
        int x = xy[0], y = xy[1];
        g.fill(x, y, x + w, y + h, 0xE510141C);
        g.fill(x, y, x + 3, y + h, accent);
        g.text(mc.font, title, x + 9, y + 7, accent, true);
        g.text(mc.font, trim(mc, detail == null ? "" : detail, w - 18), x + 9, y + 21, 0xFFABB4C2, false);
    }

    private static int[] origin(GuiGraphicsExtractor g, Models.HudPosition pos, int w, int h) {
        return switch (pos) {
            case TOP -> new int[]{(g.guiWidth() - w) / 2, 12};
            case LEFT -> new int[]{10, Math.max(10, (g.guiHeight() - h) / 2)};
            case RIGHT -> new int[]{Math.max(10, g.guiWidth() - w - 10), Math.max(10, (g.guiHeight() - h) / 2)};
            case BOTTOM -> new int[]{(g.guiWidth() - w) / 2, Math.max(10, g.guiHeight() - h - 42)};
            case OFF -> new int[]{-10000, -10000};
        };
    }

    static int categoryColor(String category) {
        return 0xFF000000 | categoryRgb(category);
    }

    static int categoryRgb(String category) {
        return switch (category.toLowerCase(Locale.ROOT)) {
            case "chest" -> 0xFFD54A;
            case "wither", "essence", "wither_essence" -> 0x55E7FF;
            case "item" -> 0x5CFF83;
            case "bat" -> 0xB86BFF;
            case "lever", "redstone_key", "key" -> 0x00E5FF;
            case "superboom" -> 0xFF7043;
            case "stonk" -> 0xFFCA28;
            case "entrance" -> 0x4FC3F7;
            case "puzzle" -> 0x40FF70;
            default -> 0xF2F5FA;
        };
    }

    private static String prettyCategory(String category) {
        return switch (category.toLowerCase(Locale.ROOT)) {
            case "wither", "essence", "wither_essence" -> "ESSENCE";
            case "superboom" -> "SUPERBOOM";
            case "puzzle" -> "PUZZLE ANSWER";
            default -> category.toUpperCase(Locale.ROOT);
        };
    }

    private static String trim(Minecraft mc, String text, int maxWidth) {
        if (text == null) return "";
        if (mc.font.width(text) <= maxWidth) return text;
        String ellipsis = "…";
        return mc.font.plainSubstrByWidth(text, Math.max(0, maxWidth - mc.font.width(ellipsis))) + ellipsis;
    }

    private static String directionArrow(double dx, double dz, float yaw) {
        double targetYaw = Math.toDegrees(Math.atan2(-dx, dz));
        double delta = (targetYaw - yaw) % 360.0;
        if (delta >= 180) delta -= 360; if (delta < -180) delta += 360;
        if (delta >= -22.5 && delta < 22.5) return "↑";
        if (delta < -22.5 && delta >= -67.5) return "↖";
        if (delta < -67.5 && delta >= -112.5) return "←";
        if (delta < -112.5 && delta >= -157.5) return "↙";
        if (delta >= 22.5 && delta < 67.5) return "↗";
        if (delta >= 67.5 && delta < 112.5) return "→";
        if (delta >= 112.5 && delta < 157.5) return "↘";
        return "↓";
    }

    private static String format1(double value) { return String.format(Locale.ROOT, "%.1f", value); }
    private record WaypointDistance(Models.WorldWaypoint waypoint, double distance) {}
}
