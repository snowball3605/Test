package dev.raistey.raisskysecrets;

import net.minecraft.client.Minecraft;
import net.minecraft.core.BlockPos;
import net.minecraft.network.chat.Component;
import net.minecraft.world.entity.decoration.ArmorStand;
import net.minecraft.world.phys.AABB;

import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Small dungeon puzzle assistant. Three Weirdos is solved dynamically; several others show short guidance. */
final class PuzzleAssistant {
    private static final Pattern THREE_WEIRDOS_CORRECT = Pattern.compile(
            "^\\[NPC] ([A-Z][a-z]+): (?:The reward is(?: not in my chest!|n't in any of our chests\\.)|"
                    + "My chest (?:doesn't have the reward\\. We are all telling the truth\\.|has the reward and I'm telling the truth!)|"
                    + "At least one of them is lying, and the reward is not in [A-Z][a-z]+'s chest!|"
                    + "Both of them are telling the truth\\. Also, [A-Z][a-z]+ has the reward in their chest!)$");
    private static final List<BlockPos> THREE_WEIRDOS_NPCS = List.of(
            new BlockPos(13, 69, 24), new BlockPos(15, 69, 25), new BlockPos(17, 69, 24));

    private String roomKey = "";
    private String dynamicHint = "";
    private Models.WorldWaypoint puzzleTarget;
    private boolean announced;

    void tick(Minecraft mc, Models.RoomCandidate room) {
        String now = room == null ? "" : room.instanceKey();
        if (!now.equals(roomKey)) {
            roomKey = now;
            dynamicHint = "";
            puzzleTarget = null;
            announced = false;
        }
    }

    void onMessage(Minecraft mc, Models.RoomCandidate room, Component component) {
        if (mc.level == null || room == null || component == null || !isThreeWeirdos(room)) return;
        String text = component.getString().replaceAll("§.", "").trim();
        Matcher matcher = THREE_WEIRDOS_CORRECT.matcher(text);
        if (!matcher.matches()) return;
        String npcName = matcher.group(1);
        BlockPos correctChest = findThreeWeirdosChest(mc, room, npcName);
        if (correctChest == null) return;
        dynamicHint = "THREE WEIRDOS → " + npcName.toUpperCase(Locale.ROOT) + "'S CHEST";
        puzzleTarget = new Models.WorldWaypoint(0, dynamicHint, "puzzle", correctChest, false);
        if (!announced && mc.player != null) {
            announced = true;
            mc.player.sendSystemMessage(Component.literal("RaisSky Puzzle · " + npcName + " 的箱子是正確答案"));
        }
    }

    void onRightClick(BlockPos clicked) {
        if (puzzleTarget == null || clicked == null) return;
        if (puzzleTarget.center().distanceToSqr(new net.minecraft.world.phys.Vec3(
                clicked.getX() + 0.5, clicked.getY() + 0.5, clicked.getZ() + 0.5)) <= 3.0 * 3.0) {
            puzzleTarget = null;
        }
    }

    Models.WorldWaypoint target() { return puzzleTarget; }

    String hint(Models.RoomCandidate room) {
        if (!dynamicHint.isBlank()) return dynamicHint;
        if (room == null) return "";
        String key = (room.definition().fileKey() + " " + room.definition().roomName()).toLowerCase(Locale.ROOT);
        if (key.contains("three-chests")) return "THREE WEIRDOS · 等 NPC 說話，RaisSky 會標綠正確箱子";
        if (key.contains("tic-tac-toe")) return "TIC TAC TOE · 先找可立即連成 3 個 X；否則先阻止 O 連線";
        if (key.contains("creeper-room")) return "CREEPER BEAMS · 將對應的光束配對穿過 Creeper";
        if (key.contains("ice-path")) return "ICE PATH · 每次滑到障礙物才停，先規劃下一個轉向點";
        if (key.contains("teleport-pad")) return "TELEPORT MAZE · 記錄已走過的傳送墊，避免回到舊路";
        if (key.contains("trivia-room")) return "TRIVIA · 先讀完整問題再選答案；不要亂踩其他答案";
        if (key.contains("water-puzzle")) return "WATER BOARD · 先確認目標出口，再依次調整閘門導水";
        if (key.contains("blaze-room")) return "BLAZE · 依房間要求由最低→最高或最高→最低血量擊殺";
        return "";
    }

    private static boolean isThreeWeirdos(Models.RoomCandidate room) {
        String key = (room.definition().fileKey() + " " + room.definition().roomName()).toLowerCase(Locale.ROOT);
        return key.contains("three-chests") || key.contains("three weirdos");
    }

    private static BlockPos findThreeWeirdosChest(Minecraft mc, Models.RoomCandidate room, String name) {
        for (BlockPos relative : THREE_WEIRDOS_NPCS) {
            BlockPos npcPos = room.relativeToActual(relative);
            AABB box = new AABB(npcPos.getX() - 1.0, npcPos.getY() - 1.0, npcPos.getZ() - 1.0,
                    npcPos.getX() + 2.0, npcPos.getY() + 3.0, npcPos.getZ() + 2.0);
            List<ArmorStand> npcs = mc.level.getEntitiesOfClass(ArmorStand.class, box,
                    entity -> entity.getName().getString().equals(name));
            if (!npcs.isEmpty()) return room.relativeToActual(relative.offset(1, 0, 0));
        }
        return null;
    }
}
