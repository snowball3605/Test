package dev.raistey.raisskysecrets;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.network.chat.Component;
import net.minecraft.world.phys.Vec3;

import java.util.Comparator;
import java.util.List;
import java.util.Locale;

final class SecretHud {
    private SecretHud() {}

    static void extract(GuiGraphicsExtractor graphics) {
        Models.HudSnapshot snapshot = ClientController.snapshot();
        if (!snapshot.enabled()) return;

        if (snapshot.databaseState() != Models.DatabaseState.READY) {
            drawStatusPill(graphics, snapshot.databaseState() == Models.DatabaseState.ERROR ? 0xFFFF667A : 0xFF69E6FF,
                    snapshot.databaseState() == Models.DatabaseState.ERROR ? "SECRET DB ERROR" : "SECRET DB LOADING",
                    snapshot.databaseMessage());
            return;
        }
        if (snapshot.waypoints().isEmpty() || snapshot.playerPos() == Vec3.ZERO) return;

        List<WaypointDistance> sorted = snapshot.waypoints().stream()
                .map(w -> new WaypointDistance(w, w.center().distanceTo(snapshot.playerPos())))
                .sorted(Comparator.comparingDouble(WaypointDistance::distance))
                .toList();
        WaypointDistance next = sorted.getFirst();
        drawMainCard(graphics, snapshot, next, sorted);
    }

    private static void drawMainCard(GuiGraphicsExtractor g, Models.HudSnapshot snapshot,
                                     WaypointDistance next, List<WaypointDistance> sorted) {
        Minecraft mc = Minecraft.getInstance();
        int width = 224;
        int x = (g.guiWidth() - width) / 2;
        int y = 14;
        int height = 58;
        int accent = categoryColor(next.waypoint.category());

        // Layered card: subtle shadow, body, top accent and a soft inner panel.
        g.fill(x + 3, y + 3, x + width + 3, y + height + 3, 0x55000000);
        g.fill(x, y, x + width, y + height, 0xDD10141C);
        g.fill(x, y, x + width, y + 2, accent);
        g.fill(x + 6, y + 25, x + width - 6, y + 43, 0x661F2633);
        int border = 0x663C4658;
        g.fill(x, y, x + width, y + 1, border);
        g.fill(x, y + height - 1, x + width, y + height, border);
        g.fill(x, y + 1, x + 1, y + height - 1, border);
        g.fill(x + width - 1, y + 1, x + width, y + height - 1, border);

        String category = prettyCategory(next.waypoint.category());
        g.text(mc.font, Component.literal("NEXT SECRET  ·  " + category), x + 8, y + 7, accent, true);

        Vec3 target = next.waypoint.center();
        double dx = target.x - snapshot.playerPos().x;
        double dy = target.y - snapshot.playerPos().y;
        double dz = target.z - snapshot.playerPos().z;
        String arrow = directionArrow(dx, dz, snapshot.playerYaw());
        String vertical = Math.abs(dy) < 1.6 ? "LEVEL" : (dy > 0 ? "▲ " + format1(Math.abs(dy)) + "m" : "▼ " + format1(Math.abs(dy)) + "m");
        String distance = format1(next.distance) + "m";
        g.text(mc.font, Component.literal(arrow + "   " + distance), x + 10, y + 30, 0xFFFFFFFF, true);
        int verticalWidth = mc.font.width(vertical);
        g.text(mc.font, Component.literal(vertical), x + width - 10 - verticalWidth, y + 30, 0xFFB7C0CE, false);

        String room = snapshot.roomName().isBlank() ? "Matching room…" : snapshot.roomName();
        String footer = room + "  ·  " + snapshot.waypoints().size() + " markers";
        g.text(mc.font, Component.literal(trimToWidth(mc, footer, width - 16)), x + 8, y + 47, 0xFF8F9BAD, false);

        // Compact right-side queue: up to three following markers.
        int listX = x + width + 8;
        int listY = y + 2;
        int shown = Math.min(3, Math.max(0, sorted.size() - 1));
        for (int i = 0; i < shown; i++) {
            WaypointDistance item = sorted.get(i + 1);
            String text = (i + 2) + "  " + prettyCategory(item.waypoint.category()) + "  " + format1(item.distance) + "m";
            int cardW = Math.min(118, mc.font.width(text) + 12);
            int cy = listY + i * 17;
            g.fill(listX, cy, listX + cardW, cy + 14, 0xAA10141C);
            g.fill(listX, cy, listX + 2, cy + 14, categoryColor(item.waypoint.category()));
            g.text(mc.font, Component.literal(trimToWidth(mc, text, cardW - 8)), listX + 6, cy + 3, 0xFFD7DCE5, false);
        }
    }

    private static void drawStatusPill(GuiGraphicsExtractor g, int accent, String title, String detail) {
        Minecraft mc = Minecraft.getInstance();
        int w = 230;
        int h = detail == null || detail.isBlank() ? 25 : 37;
        int x = (g.guiWidth() - w) / 2;
        int y = 14;
        g.fill(x + 2, y + 2, x + w + 2, y + h + 2, 0x55000000);
        g.fill(x, y, x + w, y + h, 0xDD10141C);
        g.fill(x, y, x + 3, y + h, accent);
        g.text(mc.font, Component.literal(title), x + 9, y + 7, accent, true);
        if (h > 25) g.text(mc.font, Component.literal(trimToWidth(mc, detail, w - 18)), x + 9, y + 20, 0xFFABB4C2, false);
    }

    private static String trimToWidth(Minecraft mc, String text, int maxWidth) {
        if (mc.font.width(text) <= maxWidth) return text;
        String ellipsis = "…";
        int allowed = maxWidth - mc.font.width(ellipsis);
        return mc.font.plainSubstrByWidth(text, Math.max(0, allowed)) + ellipsis;
    }

    private static String directionArrow(double dx, double dz, float playerYaw) {
        double targetYaw = Math.toDegrees(Math.atan2(-dx, dz));
        double delta = wrapDegrees(targetYaw - playerYaw);
        if (delta >= -22.5 && delta < 22.5) return "↑";
        if (delta >= 22.5 && delta < 67.5) return "↗";
        if (delta >= 67.5 && delta < 112.5) return "→";
        if (delta >= 112.5 && delta < 157.5) return "↘";
        if (delta >= 157.5 || delta < -157.5) return "↓";
        if (delta >= -157.5 && delta < -112.5) return "↙";
        if (delta >= -112.5 && delta < -67.5) return "←";
        return "↖";
    }

    private static double wrapDegrees(double value) {
        value %= 360.0;
        if (value >= 180.0) value -= 360.0;
        if (value < -180.0) value += 360.0;
        return value;
    }

    static int categoryColor(String category) {
        return switch (category.toLowerCase(Locale.ROOT)) {
            case "chest" -> 0xFFFFC857;
            case "wither" -> 0xFFC77DFF;
            case "item" -> 0xFF69E6FF;
            case "bat" -> 0xFFFF7AB8;
            case "lever" -> 0xFF7CFFB2;
            case "superboom" -> 0xFFFF9C66;
            case "stonk" -> 0xFF9DB2FF;
            case "entrance" -> 0xFFB6BEC9;
            default -> 0xFFE7EDF7;
        };
    }

    private static String prettyCategory(String category) {
        String c = category.toLowerCase(Locale.ROOT);
        return switch (c) {
            case "wither" -> "ESSENCE";
            case "superboom" -> "SUPERBOOM";
            default -> c.toUpperCase(Locale.ROOT);
        };
    }

    private static String format1(double value) {
        return String.format(Locale.ROOT, "%.1f", value);
    }

    private record WaypointDistance(Models.WorldWaypoint waypoint, double distance) {}
}
